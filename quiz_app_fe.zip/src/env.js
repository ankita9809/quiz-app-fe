const ENV = {
    baseUrl: "https://quiz-app-fmlv.onrender.com"
}


export default ENV