import { createSlice } from "@reduxjs/toolkit"

const initialState = {
    user: {}
}


const userSlice = createSlice({
    name: "userSlice",
    initialState,
    reducers: {
        setUser: (state, { payload }) => {
            console.log(">>>>>>>>>setuser",payload)
            state.user = payload
        }
    },
})


export const { setUser } = userSlice.actions

const userReducer = userSlice.reducer
export const selectToken = (state) => {
    
    return state.userReducer.user.token};
export default userReducer