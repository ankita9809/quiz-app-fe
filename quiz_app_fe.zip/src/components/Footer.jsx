import React from "react";

export default function Footer() {
  return (
    <div className="flex flex-row justify-center  bg-white px-8  mt-5 ">
      Copy right reserved
    </div>
  );
}
